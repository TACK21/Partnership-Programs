package com.theboys.Software.Engineer.dto.user;

import com.theboys.Software.Engineer.model.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
@Getter
@Setter
public class UserMapper {
    private final ModelMapper modelMapper;
    public User convertToUserEntity(UserDto userDto){
        return modelMapper.map(userDto, User.class);
    }
    public UserDto convertToUserDto(User user){
        return modelMapper.map(user, UserDto.class);
    }
}
