package com.theboys.Software.Engineer.controller;

import com.theboys.Software.Engineer.dto.program.ProgramDto;
import com.theboys.Software.Engineer.service.program.ProgramService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/programs")
@AllArgsConstructor
public class ProgramController {
    private final ProgramService programService;

    @GetMapping("/all")
    public List<ProgramDto> getAllPrograms(){
        return programService.getAllPrograms();
    }


    @GetMapping("/programs/subscribed/{userId}")
    public List<ProgramDto> getSubscribesOfUser(@PathVariable long userId){
        return programService.getSubscribedProgramsForUser(userId);
    }


    @GetMapping("/programs/popular")
    public List<ProgramDto> getProgramByPopular(){
        return programService.getProgramsByPopular();
    }
}

