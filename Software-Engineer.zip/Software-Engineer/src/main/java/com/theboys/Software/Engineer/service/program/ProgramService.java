package com.theboys.Software.Engineer.service.program;

import com.theboys.Software.Engineer.dto.program.ProgramDto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ProgramService {
    List<ProgramDto> getAllPrograms();

    List<ProgramDto> getSubscribedProgramsForUser(long userId);

    List<ProgramDto> getProgramsByPopular();
}
