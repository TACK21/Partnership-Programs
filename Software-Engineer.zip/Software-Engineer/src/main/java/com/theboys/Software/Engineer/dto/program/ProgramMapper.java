package com.theboys.Software.Engineer.dto.program;

import com.theboys.Software.Engineer.model.Program;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@Getter
@Setter
@Component
public class ProgramMapper {
    private final ModelMapper modelMapper;

    public Program convertToProgramEntity(ProgramDto programDto){
        return modelMapper.map(programDto,Program.class);
    }

    public ProgramDto convertToProgramDto(Program program){
        return modelMapper.map(program,ProgramDto.class);
    }

    public List<ProgramDto> convertToProgramDtoList(List<Program> programs){
        List<ProgramDto> programDtoList = new ArrayList<>();
        for (Program p : programs){
            programDtoList.add(convertToProgramDto(p));
        }
        return programDtoList;
    }
}
