package com.theboys.Software.Engineer.service.program;

import com.theboys.Software.Engineer.dto.program.ProgramDto;
import com.theboys.Software.Engineer.dto.program.ProgramMapper;
import com.theboys.Software.Engineer.model.Program;
import com.theboys.Software.Engineer.repository.ProgramRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class ProgramServiceImpl implements ProgramService {
    private final ProgramRepository programRepository;
    private final ProgramMapper programMapper;

    @Override
    public List<ProgramDto> getAllPrograms() {
        List<Program> programs = programRepository.findAll();
        return programMapper.convertToProgramDtoList(programs);
    }

    @Override
    public List<ProgramDto> getSubscribedProgramsForUser(long userId) {
        List<Program> programs = programRepository.findProgramsByUserId(userId);
        List<ProgramDto> programDto = new ArrayList<>();
        for (Program program : programs) {
            programDto.add(programMapper.convertToProgramDto(program));
        }
        return programDto;
    }

    @Override
    public List<ProgramDto> getProgramsByPopular(){
        List<Program> programs = programRepository.findAllByOrderByPopularityDesc();
        List<ProgramDto> programDto = new ArrayList<>();
        for (Program program : programs) {
            programDto.add(programMapper.convertToProgramDto(program));
        }
        return programDto;
    }
}
