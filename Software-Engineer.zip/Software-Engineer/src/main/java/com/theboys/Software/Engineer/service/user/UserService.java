package com.theboys.Software.Engineer.service.user;

import com.theboys.Software.Engineer.dto.user.UserDto;
import org.springframework.stereotype.Service;

@Service
public interface UserService {


    UserDto register(UserDto userDto);

    UserDto getUser(long id);

    void subscribe(long userId, long programId);
}
