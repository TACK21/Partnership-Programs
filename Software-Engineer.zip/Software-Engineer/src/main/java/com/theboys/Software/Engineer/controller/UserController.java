package com.theboys.Software.Engineer.controller;

import com.theboys.Software.Engineer.dto.user.UserDto;
import com.theboys.Software.Engineer.service.user.UserService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
public class UserController {
    private final UserService userService;

    @PostMapping("/register")
    @Operation(summary = "register", description = "method register user")
    public UserDto register(@RequestBody UserDto userDto){
        return userService.register(userDto);
    }



    @GetMapping("/get-profile/{userId}")
    @Operation(summary = "get", description = "method get users profile")
    public UserDto getProfile(@PathVariable long userId){
        return userService.getUser(userId);
    }



    @PostMapping("/sub/{userId}/{programId}")
    @Operation(summary = "subscription", description = "method subscribe user on Program")
    public void subscribe(@PathVariable long userId,
                         @PathVariable long programId) {
        userService.subscribe(userId, programId);
    }


}
