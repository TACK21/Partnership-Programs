package com.theboys.Software.Engineer.service.user;

import com.theboys.Software.Engineer.dto.user.UserDto;
import com.theboys.Software.Engineer.dto.user.UserMapper;
import com.theboys.Software.Engineer.model.Program;
import com.theboys.Software.Engineer.model.User;
import com.theboys.Software.Engineer.repository.ProgramRepository;
import com.theboys.Software.Engineer.repository.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;


@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService{

    private final UserRepository userRepository;
    private final UserMapper userMapper;
    private final ProgramRepository programRepository;

    @Override
    public UserDto register(UserDto userDto) {
        User user = userMapper.convertToUserEntity(userDto);
        if(userRepository.existsByNameAndEmail(user.getName(), user.getEmail())){
            throw new RuntimeException("User already exists");
        }else{
            User savedUser = userRepository.save(user);
            return userMapper.convertToUserDto(savedUser);
        }
    }

    @Override
    public UserDto getUser(long id) {

        return userMapper.convertToUserDto(userRepository.getById(id));
    }

    @Override
    public void subscribe(long userId, long programId) {
        User user = userMapper.convertToUserEntity(getUser(userId));
        Program program = programRepository.findById(programId).orElse(null);
        if (user != null && program != null) {
            program.getUsers().add(user);
            programRepository.save(program);
        }
    }

    public String loginUser(String email , String password){
        return null;
    }




}
