package com.theboys.Software.Engineer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftwareEngineerApplicationTests {

	@Test
	void contextLoads() {
	}

}
